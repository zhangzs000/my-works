/*
* @Author: Administrator
* @Date:   2017-11-21 20:00:32
* @Last Modified by:   Administrator
*/

(function(root){
  var modMap = {};
  var moduleMap = {};
  var cfg = {
    baseUrl: location.href.replace(/(\/)[^\/]+$/g, function(s, s1){
      return s1
    }),
    path: {

    }
  };
  
  // 完整网址
  var fullPathRegExp = /^[(https?\:\/\/) | (file\:\/\/\/)]/;
  
  // 局对路径
  var absoPathRegExp = /^\//;
  
  // 以./开头的相对路径
  var relaPathRegExp = /^\.\//;
  
  // 以../开头的的相对路径
  var relaPathBackRegExp = /^\.\.\//;

  //类型检测
  function isFun(f) {
    return Object.prototype.toString.call(f).toLowerCase().indexOf('function') > -1;
  }

  function isArr(arr) {
    return Array.isArray(arr);
  }

  function isStr(str) {
    return typeof str === 'string';
  }
  
  function merge(obj1, obj2) {
    if(obj1 && obj2) {
      for(var key in obj2) {
        obj1[key] = obj2[key]
      }
    }
  }
  
  function outputPath(baseUrl, path) {
    if (relaPathRegExp.test(path)) {
      if(/\.\.\//g.test(path)) {
        var pathArr = baseUrl.split('/');
        var backPath = path.match(/\.\.\//g);
        var joinPath = path.replace(/[(^\./)|(\.\.\/)]+/g, '');
        var num = pathArr.length - backPath.length;
        return pathArr.splice(0, num).join('/').replace(/\/$/g, '') + '/' +joinPath;
      } else {
        return baseUrl.replace(/\/$/g, '') + '/' + path.replace(/[(^\./)]+/g, '');
      }
    } else if (fullPathRegExp.test(path)) {
      return path;
    } else if (absoPathRegExp.test(path)) {
      return baseUrl.replace(/\/$/g, '') + path;
    } else {
      return baseUrl.replace(/\/$/g, '') + '/' + path;
    }
  }

  function replaceName(name) {
    if(name===null) {
      return name;
    }
    if(fullPathRegExp.test(name) || absoPathRegExp.test(name) || relaPathRegExp.test(name) || relaPathBackRegExp.test(name)) {
      return outputPath(cfg.baseUrl, name);
    } else {
      var prefix = name.split('/')[0] || name;
      if(cfg.paths[prefix]) {
        if(name.split('/').length === 0) {
         return cfg.paths[prefix];
        } else {;
          var endPath = name.split('/').slice(1).join('/');
          return outputPath(cfg.paths[prefix], endPath);
        }
      } else {
        return outputPath(cfg.baseUrl, name);
      }
    }
  }

  function fixUrl(name) {
    return name.split('/')[name.split('/').length-1]
  }
  function config(obj) {
    if(obj){
     if(obj.baseUrl) {
       obj.baseUrl = outputPath(cfg.baseUrl, obj.baseUrl);
     }
     if(obj.paths) {
       var base = obj.baseUrl || cfg.baseUrl;
       for(var key in obj.paths) {
         obj.paths[key] = outputPath(base, obj.paths[key]);
       }
     }
      merge(cfg, obj);
    }
  }


  
  function use(deps, callback) {
    if(deps.length == 0) {
      callback();
    }
    var depsLength = deps.length;
    var params = [];
    
    for(var i = 0; i < deps.length; i++) {
      moduleMap[fixUrl(deps[i])] = deps[i];
      deps[i] = replaceName(deps[i]);
      (function(j){
        loadMod(deps[j], function(param) {
          depsLength--;
          params[j] = param;
          if(depsLength === 0) {
            callback.apply(null, params);
          }
        })
      })(i)
    }
    
  }

  function loadMod(name, callback) {
    /*模块还未定义*/
    if(!modMap[name]) {
      modMap[name] = {
        status: 'loading',
        oncomplete: []
      };
      loadscript(name, function() {
        use(modMap[name].deps, function() {
          execMod(name, callback, Array.prototype.slice.call(arguments, 0));
        })
      });
    } else if(modMap[name].status === 'loading') {
      
      // 模块正在加载
      modMap[name].oncomplete.push(callback);
    } else if (!modMap[name].exports){
      
      //模块还未执行完
      use(modMap[name].deps, function() {
        execMod(name, callback, Array.prototype.slice.call(arguments, 0));
      })
    }else {
      callback(modMap[name].exports);
    }
  }

  function execMod(name, callback, params) {
    var exp = modMap[name].callback.apply(null, params);
    modMap[name].exports = exp;
    callback(exp);
    execComplete(name);
  }

  function execComplete(name) {
    for(var i = 0; i < modMap[name].oncomplete.length; i++) {
      modMap[name].oncomplete[i](modMap[name].exports);
    }
  }
  
  
  function loadscript(name, callback) {
    var doc = document;
    var node = doc.createElement('script');
    node.charset = 'utf-8';
    node.src = name + '.js';
    
    /*为每个模块添加一个随机id*/
    node.id = 'loadjs-js-' + (Math.random() * 100).toFixed(3);
    doc.body.appendChild(node);
    node.onload = function() {
      callback();
    }
  }

//定义模块的时候通过arguments 参数列表做类型检测
  function define(name, deps, callback) {
    /*匿名模块*/
    if(!isStr(name)) {
      callback = deps;
      deps = name;
      name = null;
    }

    /*没有依赖*/
    if(!isArr(deps)) {
      callback = deps;
      deps = [];
    }

    if(moduleMap[name]) {
      name=moduleMap[name]
    } 
    
    name = replaceName(name);
    
    /*对每个依赖名进行路径替换*/
    deps = deps.map(function(ele, i) {
      return replaceName(ele); 
    });

    modMap[name] = modMap[name] || {};
    modMap[name].deps = deps;
    modMap[name].status = 'loaded';
    modMap[name].callback = callback;
    modMap[name].oncomplete = modMap[name].oncomplete || [];
  }

  var maxjs = {
    define: define,
    use: use,
    config: config
  };

  root.define = define;
  root.maxjs = maxjs;
  root.modMap = modMap;
})(window);