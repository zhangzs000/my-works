/*
* @Author: Administrator
* @Date:  2017-11-19 21:00:32
* @Last Modified by:   Administrator
*/
define("a",[],function(){
	return {
		add:function(a,b){
			console.log(a+b);
		}
	}
});