/*
* @Author: Administrator
* @Date:  2017-11-19 21:05:22
* @Last Modified by:   Administrator
*/
define("b",[],function(){
	return {
		delete:function(a,b){
			console.log(a-b);
		}
	}
});